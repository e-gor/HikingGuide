HikingGuide
===========

A guide that will help you in your hikes with maps, tracks and GPS position.

Hiking Guide is a web app written in HTML, Javascript and CSS, and has been tested on Firefox.

It works with GPX and KML tracks. On a Firefox OS phone, tracks must be located in a directory called "tracks" in the SD card.

Hiking Guide uses the OpenLayers (http://www.openlayers.org/) and Enyo (http://enyojs.com/) libraries.
